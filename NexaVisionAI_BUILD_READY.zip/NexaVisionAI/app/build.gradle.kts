plugins {
    id("com.android.application")
}

android {
    namespace = "com.nexavision.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexavision.ai"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
